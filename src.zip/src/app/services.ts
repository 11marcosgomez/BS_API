
import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { ApiAOT, Result } from "./common/api-aot";


@Injectable({
    providedIn: 'root'
  })

export class Services {

    constructor(private http: HttpClient) { }
    loadDigimon(): Observable<ApiAOT>{
      return this.http.get<ApiAOT>("https://api.attackontitanapi.com/characters");
    }    
    loadChar(id: string): Observable <ApiAOT>{
      return this.http.get<ApiAOT>("https://api.attackontitanapi.com/characters/" + id);
    }
    reloadPag(pag: string): Observable <ApiAOT>{
      return this.http.get<ApiAOT>(pag);
    }
   
}
